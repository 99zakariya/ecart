from django.shortcuts import render
from .models import cati,pro,costom,order
from django.http import HttpResponse,HttpResponseRedirect
from .forms import CoustomerForm
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from django import forms
from django.contrib.auth.decorators import login_required


# Create your views here.
def index(re):
    ob=cati.objects.all()
    o=pro.objects.all()

    return  render(re,"pages/main.html",{"cat":ob,"p":o})
def cat(re,o):
    ob = cati.objects.all()
    s=cati.objects.filter(cat_id=o)
    o = pro.objects.filter(cat_id=o)
    #
    # return render(re, "pages/main.html", {"cat": ob, "p": o})
    return HttpResponse(o[0].pro_name)
def reg(request):
    if request.method == "POST":
        form = CoustomerForm(request.POST)
        if form.is_valid():

            userObj = form.cleaned_data
            username = userObj['cu_name']
            email = userObj['cu_email']
            password = userObj['cu_pass']
            if not (User.objects.filter(username=username).exists() or User.objects.filter(email=email).exists()):
                User.objects.create_user(username, email, password)
                user = authenticate(username=username, password=password)
                form.save()
                login(request, user)
                return HttpResponseRedirect('/shop')
            else:
                raise forms.ValidationError('Looks like a username with that email or password already exists')
    else:
        form = CoustomerForm
    return render(request, 'pages/reg.html', {'form': form})

@login_required(login_url='/shop/login')
def add(request,id):
    pr=pro.objects.get(pro_id=id)
    cus = request.user.username
    cust=costom.objects.filter(cu_name=cus)
    if len(cust)<1:
        return HttpResponse("plz log in with diffrent accout")
    else:
        d=order(od_price=pr.pro_price,cus_id=cust[0],pro_id=pr)
        d.save()
    return HttpResponseRedirect('/shop/cart')

@login_required(login_url='/shop/login')
def cart(request):
    cus = request.user.username
    cust = costom.objects.filter(cu_name=cus)
    if len(cust) < 1:
        return HttpResponse("plz log in with diffrent accout")
    else:
        od=order.objects.filter(cus_id=cust[0],od_st=False)
        return render(request,"pages/cart.html",{"o":od})


@login_required(login_url='/shop/login')
def dell(request,id):
    order.objects.get(od_id=id).delete()
    return HttpResponseRedirect('/shop/cart')
@login_required(login_url='/shop/login')
def che(request):
    cus = request.user.username
    cust = costom.objects.filter(cu_name=cus)
    if len(cust) < 1:
        return HttpResponse("plz log in with diffrent accout")
    else:
        od = order.objects.filter(cus_id=cust[0], od_st=False)
        for s in od:
            s.od_st=True
            s.save()
        return HttpResponseRedirect('/shop')
