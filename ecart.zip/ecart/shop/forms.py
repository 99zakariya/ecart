from .models import costom
from django import  forms
class CoustomerForm(forms.ModelForm):
    class Meta:
        model = costom
        fields = ["cu_name","cu_mob","cu_pass","cu_email"]