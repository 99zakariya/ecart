from pyexpat import model

from django.db import models

# Create your models here.
from docutils.utils.math.latex2mathml import mo


class costom(models.Model):
    cu_id=models.AutoField(primary_key=True)
    cu_name=models.CharField(max_length=40)
    cu_mob=models.CharField(max_length=15)
    cu_email=models.EmailField(max_length=40)
    cu_pass=models.CharField(max_length=100)
    cu_role=models.CharField(max_length=20,default='user')
    class Meta:
        db_table="coustomer"


class cati(models.Model):
    cat_id=models.AutoField(primary_key=True)
    cat_name=models.CharField(max_length=50)
    class Meta:
        db_table="cati"

class pro(models.Model):
    pro_id=models.AutoField(primary_key=True)
    pro_name=models.CharField(max_length=50)
    pro_price=models.FloatField(default=0.0)
    pro_dis=models.CharField(max_length=400)
    cat_id=models.ForeignKey(cati,on_delete=models.CASCADE)
    pro_img=models.ImageField(upload_to="pro_img",blank=True)

class order(models.Model):
    od_id=models.AutoField(primary_key=True)
    od_dt=models.DateField(auto_now=True)
    od_qt=models.IntegerField(default=1)
    od_price=models.FloatField(default=0.0)
    od_st=models.BooleanField(default=False)
    cus_id=models.ForeignKey(costom,on_delete=models.SET_NULL,null=True)
    pro_id=models.ForeignKey(pro,on_delete=models.SET_NULL,null=True)
    class Meta:
        db_table="order"