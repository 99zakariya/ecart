from django.contrib import admin
from .models import cati,pro

# Register your models here.
admin.site.register(cati)
admin.site.register(pro)

