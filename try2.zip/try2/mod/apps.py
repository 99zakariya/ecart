from django.apps import AppConfig


class ModConfig(AppConfig):
    name = 'mod'
