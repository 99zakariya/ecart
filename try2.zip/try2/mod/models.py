from django.db import models

# Create your models here.
from django.forms import CharField


class emp2(models.Model):
    ename=models.CharField(max_length=40)
    class Meta:
        db_table = "emp"